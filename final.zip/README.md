Welcome to Clayton and Nicks Final Project.

This program runs in Python2 and requires the following libraries:

sys, random, flask and PIL



Once you are in the same directory as the Project you need to simply run the server.py file once with python server.py and link it to flask using export FLASK_APP=server.py. You can then run the flask server with flask run --host=0.0.0.0 --port=8081 if you are on cloud9. All of the commands are contained within our paper and the steganography library. Simply change the end point to your own in order to test for functionality.